package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPageObject {
	public WebDriver driver;
	By CloseIcon= By.xpath("//button[@class='_2AkmmA _29YdH8']");
	

    By addtocarditemDetails=By.xpath("//span[contains(text(),'Cart')]");  

    By Title=By.xpath("//span[contains(text(),'Cart')]");

	public LandingPageObject(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		}







	

	public WebElement getCloseIcon()
	{
		return driver.findElement(CloseIcon);
	}





	public WebElement getaddtocarditemDetails() {
		// TODO Auto-generated method stub
		return driver.findElement(addtocarditemDetails);
	}






	public WebElement getTitle() {
		// TODO Auto-generated method stub
		return driver.findElement(Title);
	}


	

}
