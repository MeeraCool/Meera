package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class myCartPageObjects {
	public WebDriver driver;
	By PlaceOrderButton= By.xpath("//span[contains(text(),'Place Order')]");
	

    By addtocarditemDetails=By.xpath("//span[contains(text(),'Cart')]");


	public myCartPageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		}

 





	

	public WebElement getPlaceOrderButton()
	{
		return driver.findElement(PlaceOrderButton);
	}
	public WebElement getaddtocarditemDetails()
	{
		return driver.findElement(addtocarditemDetails);
	}
}
