package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class addtoCardObjects {
	public WebDriver driver;
	By Electronics=By.xpath("//span[contains(text(),'Electronics')] ");
	By Oppo=By.xpath("//li[@class='_1KCOnI _3ZgIXy']//a[contains(text(),'OPPO')]");
	By Oppopurple=By.linkText("OPPO A83 (Champagne, 16 GB)");  
	By addtocard=By.xpath("//button[@class='_2AkmmA _2Npkh4 _2MWPVK']"); 
	By flipkartHome=By.xpath("//img[@class='_1e_EAo']");
	public addtoCardObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		}
	public WebElement getElectronics() {
		// TODO Auto-generated method stub
		return driver.findElement(Electronics);
	}
	public WebElement getOppo() {
		// TODO Auto-generated method stub
		return driver.findElement(Oppo);
	}
	public WebElement getOppopurple() {
		// TODO Auto-generated method stub
		return driver.findElement(Oppopurple);
	}
	public WebElement getaddtocard() {
		// TODO Auto-generated method stub
		return driver.findElement(addtocard);
	}
	public WebElement getflipkartHome() {
		// TODO Auto-generated method stub
		return driver.findElement(flipkartHome);
	}
}
