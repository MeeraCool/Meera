package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class loginPageObjects {
	public WebDriver driver;
	
	//input[@class='_2zrpKA _14H79F']  
   
    By MobileNumber=By.xpath("//input[@class='_2zrpKA _14H79F']");  
    By ContinueButton=By.xpath("//span[contains(text(),'CONTINUE')]");
	By Password=By.xpath("//input[@class='_2zrpKA _3v41xv _14H79F']"); 
	
	By LoginButton=By.xpath("//button[@class='_2AkmmA _1poQZq _7UHT_c']");  
	By DeliverHereButton=By.xpath("//button[@class='_2AkmmA _I6-pD _7UHT_c']");
	//button[@class='_2AkmmA _2Q4i61 _7UHT_c'] 
	public loginPageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stu
		
		this.driver=driver;
		
	}


	

	
	public WebElement getContinueButton()
	{
		return driver.findElement(ContinueButton);
	}
	
	public WebElement getMobileNumber()
	{
		return driver.findElement(MobileNumber);
	}
	
	
	public WebElement getPassword()
	{
		return driver.findElement(Password);
	}

	public WebElement getLoginButton()
	{
		return driver.findElement(LoginButton);
	}
	public WebElement getDeliverHereButton()
	{
		return driver.findElement(DeliverHereButton);
	}
}
