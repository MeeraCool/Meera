package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class orderSummayPageObjects {
	public WebDriver driver;
	
	 
	
    By OrderSummaryContinueButton=By.xpath("//button[@class='_2AkmmA _2Q4i61 _7UHT_c']");
    		 
    By NetBankingRadioButton=By.xpath("//label[@class='_8J-bZE _3C6tOa _2i24Q8']//div[@class='_3i_pKg'][contains(text(),'Net Banking')]"); 
    By SelectBankDropdown=By.xpath("//select[@class='_1CV081']");
    
    By FinalContinueButton=By.xpath("//button[@class='_2AkmmA _14O7kc _7UHT_c']");
  
 


	public orderSummayPageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		}


	

	
	public WebElement getNetBankingRadioButton()
	{
		return driver.findElement(NetBankingRadioButton);
	}
	
	public WebElement getOrderSummayContinueButton()
	{
		return driver.findElement(OrderSummaryContinueButton);
	}
	public WebElement getSelectBankDropdown()
	{
		return driver.findElement(SelectBankDropdown);
	}
	public WebElement getFinalContinueButton()
	{
		return driver.findElement(FinalContinueButton);
	}
}
