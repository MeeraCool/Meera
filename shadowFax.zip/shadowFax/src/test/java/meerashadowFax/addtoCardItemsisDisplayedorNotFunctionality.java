
package meerashadowFax;

import org.testng.annotations.Test;

import com.google.common.io.Files;

import org.testng.AssertJUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.IOException;
import org.openqa.selenium.support.ui.Select;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pageObjects.LandingPageObject;
import pageObjects.addtoCardObjects;
import pageObjects.loginPageObjects;
import pageObjects.myCartPageObjects;
import pageObjects.orderSummayPageObjects;
import resources.base;

public class addtoCardItemsisDisplayedorNotFunctionality extends base{
	public static Logger log =LogManager.getLogger(base.class.getName());
	@BeforeClass

	public void initialize() throws IOException, InterruptedException
	{
//a.Open https://www.flipkart.com/ in an un-signed state
		
		 driver =initializeDriver();
		 log.info("Driver is initialized");
			
		 driver.get(prop.getProperty("url"));
		 log.info("Url is loaded");
		
	
		LandingPageObject close =new LandingPageObject(driver);
		Thread.sleep(1000);
		close.getCloseIcon().click();
		 log.info("Home page is loaded");
		driver.manage().window().maximize();
        addtoCardObjects atc=new addtoCardObjects(driver);
        
        
// b.Go to Electronics/Mobile section, choose OPPO//    
        atc.getElectronics().click();
        Thread.sleep(3000);
        atc.getOppo().click();
       
//c.Select item with name OPPO A83 (Champagne, 16 GB)  (2 GB RAM)
         String winHandleBefore = driver.getWindowHandle();
         atc.getOppopurple().click();
 
      for(String winHandle : driver.getWindowHandles()){
          driver.switchTo().window(winHandle);
      }
//d.Click on ‘Add to Cart’
         atc.getaddtocard().click();
         
//e.Click on Flipkart main icon to go back to home screen        
         atc.getflipkartHome().click();

         driver.switchTo().window(winHandleBefore);
     

	}
	
	@Test(priority=1)
	
	public void validateaddedCardItemsDisplayedorNot() throws IOException, InterruptedException
	{
		
	
  
      LandingPageObject l=new LandingPageObject(driver);
      l.getaddtocarditemDetails().click();
      
//f.Click on Cart and verify if item exists in the page.
	    AssertJUnit.assertTrue(l.getaddtocarditemDetails().isDisplayed());
	    log.info("Added cart details items is displayed");
		

		
	}
@Test(priority=2)
//g.Click on Place Order
	public void placeOrder()
	{
	    myCartPageObjects mp=new myCartPageObjects(driver);
	    mp.getPlaceOrderButton().click();
}
		
@Test(dataProvider="getData",priority=3)
//h.Login using your account. Make one if don’t have already.
    public void loginFunctionality(String MobileNumber,String Password) throws IOException, InterruptedException
    {
	    loginPageObjects lp = new loginPageObjects(driver);
	    lp.getMobileNumber().click();
	
	   lp.getMobileNumber().sendKeys(MobileNumber);
	   lp.getContinueButton().click();

       lp.getPassword().click();
       lp.getPassword().sendKeys(Password);
       lp.getLoginButton().click();

}

@Test(priority=4)
//i.Add order confirmation email and press continue
    public void deliveryandOrderSummary() throws InterruptedException
{
	   loginPageObjects lp = new loginPageObjects(driver);
	   lp.getDeliverHereButton().click();
	   orderSummayPageObjects order=new orderSummayPageObjects(driver);
	
	     order.getOrderSummayContinueButton().click();
	     order.getNetBankingRadioButton().click();
	
	
}
@Test(priority=5)
//j.On payments options, select net banking, select Corporation Bank
	public void selectOtherBank() throws InterruptedException
	{
	Select select=new Select(driver.findElement(By.xpath("//select[@class='_1CV081']")));
   select.selectByVisibleText("Corporation Bank");
   

	orderSummayPageObjects order=new orderSummayPageObjects(driver);
	order.getFinalContinueButton().click();
	}
	
	
@Test(priority=6)
//k.Take screenshot of the Bank screen.
   public void getScreenshot() throws IOException
	{
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Files.copy(src, new File("/home/i-exceed.com/screenshot.png"));
	}
	
	
	

	
	
	




@DataProvider
public Object[][] getData()
{
	
	Object[][] data=new Object[1][2];
	
	data[0][0]="8508072103";
	data[0][1]="Meera@123";
	

	return data;
	

}
		
	@AfterClass
	public void teardown()
	{
		
		driver.close();
		driver=null;
		
	}
	
}