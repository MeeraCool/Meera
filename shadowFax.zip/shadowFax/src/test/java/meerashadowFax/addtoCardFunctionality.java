package meerashadowFax;

import java.io.IOException;
import java.util.List;

import org.apache.bcel.generic.Select;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.LandingPageObject;
import pageObjects.addtoCardObjects;
import resources.base;

public class addtoCardFunctionality extends base{
	public static Logger log =LogManager.getLogger(addtoCardFunctionality.class.getName());
	@BeforeTest

	public void initialize() throws IOException
	{
		driver =initializeDriver();
		 log.info("Driver is initialized");
			

			driver.get(prop.getProperty("url"));
			log.info("Url is loaded");
		
	}
	@Test()
	public void homePageNavigation()throws IOException, InterruptedException
	{
		LandingPageObject close =new LandingPageObject(driver);
		Thread.sleep(1000);
		close.getCloseIcon().click();
		 log.info("Home page is loaded");
		driver.manage().window().maximize();
        addtoCardObjects atc=new addtoCardObjects(driver);
        
        
// b.Go to Electronics/Mobile section, choose OPPO//    
        atc.getElectronics().click();
        Thread.sleep(3000);
        atc.getOppo().click();
       
//c.Select item with name OPPO A83 (Champagne, 16 GB)  (2 GB RAM)
         String winHandleBefore = driver.getWindowHandle();
         atc.getOppopurple().click();
 
      for(String winHandle : driver.getWindowHandles()){
          driver.switchTo().window(winHandle);
      }
//d.Click on ‘Add to Cart’
         atc.getaddtocard().click();
         
 
         
//e.Click on Flipkart main icon to go back to home screen        
         atc.getflipkartHome().click();

         driver.switchTo().window(winHandleBefore);
	}

	@AfterTest
	public void teardown()
	{
		
		driver.close();
		driver=null;
		
	}
}
