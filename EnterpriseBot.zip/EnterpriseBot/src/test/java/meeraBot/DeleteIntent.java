package meeraBot;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObjects.DeletePageObjects;
import pageObjects.LandingPageHome;
import pageObjects.LoginPageObjectbot;
import pageObjects.SearchPageObjects;
import resources.base;

public class DeleteIntent extends base {
	public static Logger log = LogManager.getLogger(Login.class.getName());

	@BeforeTest
	public void initialize() throws IOException {

		driver = initializeDriver();
		log.info("Driver is initialized");

		driver.get(prop.getProperty("url"));
		log.info("Url is loaded");

	}

	@Test(dataProvider = "getData")
	public void LoginPage(String BusinessEmail, String Password) throws IOException, InterruptedException {

		System.out.println(BusinessEmail);
		log.info("SignInpage is loaded");
		System.out.println(Password);
		
		LoginPageObjectbot lg = new LoginPageObjectbot(driver);

		lg.getBusinessEmail().sendKeys(BusinessEmail);

		lg.getPassword().sendKeys(Password);
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		//lg.getSignIn().click();
		lg.getBusinessEmail().sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		log.info("login pass");
	LandingPageHome ch=new LandingPageHome(driver);
	
	ch.getCreateIntent().click();
	Thread.sleep(5000);
	ch.getIntentName().sendKeys("Meera1");
	ch.getInputTrigger().sendKeys("testinggg");
	ch.getInputTrigger().sendKeys(Keys.ENTER);
	ch.getSave().click();
	SearchPageObjects search=new SearchPageObjects(driver);
	search.getSeachInput().sendKeys("Meera");
	search.getSeachInput().sendKeys(Keys.ENTER);
	search.SeachResult().click();
	DeletePageObjects dl=new DeletePageObjects(driver);
	dl.getDeleteIcon().click();
	driver.switchTo().alert().accept();
	log.info("Intent deleted successfully");
	}

	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[2][2];

		data[0][0] = "suraj+tester@enterprisebot.org";
		data[0][1] = "E13_Tester";

		return data;

	}

}

