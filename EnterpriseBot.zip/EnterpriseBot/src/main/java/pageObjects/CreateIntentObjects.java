package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import resources.base;

public class CreateIntentObjects extends base{


	public WebDriver driver;
	By CreateIntentButton=By.xpath("//div[@class='btn btn-success agent-save-button']");
    By IntentName=By.cssSelector("#intent-header-name");
    By trigger=By.cssSelector("#trigger-input");
    By Response=By.xpath("//img[@class='img replies']");
 By AddReply=By.xpath("//input[@placeholder='Add reply']") ;
    By Save=By.xpath("//button[@id='intent-save-btn']");

    public void LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
		}
	






	public WebElement getCreateIntentButton() {
		// TODO Auto-generated method stub
		return driver.findElement(CreateIntentButton);
	}
		public WebElement getIntentName() {
			// TODO Auto-generated method stub
			return driver.findElement(IntentName);
		}
			public WebElement gettrigger() {
				// TODO Auto-generated method stub
				return driver.findElement(trigger);
			}
			public WebElement getResponse() {
				// TODO Auto-generated method stub
				return driver.findElement(Response);
			}
			public WebElement getAddReply() {
				// TODO Auto-generated method stub
				return driver.findElement(AddReply);
			}
			
			
		}
		

