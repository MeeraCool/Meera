package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DeletePageObjects {
	public WebDriver driver;
	By DeleteIcon = By.xpath("//img[@class='image']");
	By Yes =By.xpath("//p[contains(text(),'Yes')]");
	
	public DeletePageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	public WebElement getDeleteIcon() {
		// TODO Auto-generated method stub
		return driver.findElement(DeleteIcon);
	}
	public WebElement getYes() {
		// TODO Auto-generated method stub
		return driver.findElement(Yes);
	}
}
