package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchPageObjects {
	public WebDriver driver;
	By SeachInput = By.xpath("//input[@id='search-form']");
	By SeachResult = By.xpath("//li[@title='Meera']");
	public SearchPageObjects(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	public WebElement getSeachInput() {
		// TODO Auto-generated method stub
		return driver.findElement(SeachInput);
	}
	public WebElement SeachResult() {
		// TODO Auto-generated method stub
		return driver.findElement(SeachResult);
	}
}
