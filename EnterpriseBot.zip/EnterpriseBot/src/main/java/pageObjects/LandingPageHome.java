package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LandingPageHome {


	public WebDriver driver;
	
	 By CreateIntent=By.xpath("//button[@title='Click to create new intent']");
	 By IntentName=By.xpath("//input[@id='intent-header-name']");
	 By InputTrigger=By.xpath("//input[@id='trigger-input']");
	 By Save=By.xpath("//button[@id='intent-save-btn']");
	
    

	public LandingPageHome(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver=driver;
	}

	
	
	public WebElement getCreateIntent() {
				// TODO Auto-generated method stub
				return driver.findElement(CreateIntent);
			}
	public WebElement getInputTrigger() {
		// TODO Auto-generated method stub
		return driver.findElement(InputTrigger);
	}
	public WebElement getIntentName() {
		// TODO Auto-generated method stub
		return driver.findElement(IntentName);
	}
	public WebElement getSave() {
		// TODO Auto-generated method stub
		return driver.findElement(Save);
	}
}
