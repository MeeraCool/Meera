package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPageObjectbot {

	public WebDriver driver;
	By BusinessEmail = By.xpath(
			"//div[@class='login-input col-lg-12 col-md-12 col-sm-12 padding-none pull-left']//div[1]//input[1]");
	By Password = By.xpath("//div[@class='container-fluid login-page-background signin-form']//div[2]//input[1]");
	By SignIn = By.xpath("//button[contains(text(),'Sign In')]");

	public LoginPageObjectbot(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	public WebElement getBusinessEmail() {
		// TODO Auto-generated method stub
		return driver.findElement(BusinessEmail);
	}

	public WebElement getPassword() {
		// TODO Auto-generated method stub
		return driver.findElement(Password);
	}

	public WebElement getSignIn() {
		// TODO Auto-generated method stub
		return driver.findElement(SignIn);

	}
}
